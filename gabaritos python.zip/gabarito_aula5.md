# Gabarito: Estruturas de Repetição e Heurísticas de Acumulação
**Disciplina:** Fundamentos de Algoritmos

Prof. Dr. Murillo Bouzon

---

## Exercício 6: Acumulador com Condição de Parada Dinâmica

**1. Pseudocódigo**
```text
total <- 0
soma <- 0
enquanto Verdadeiro faca
    leia x
    se x == 0 entao
        interrompa
    fimse
    total <- total + 1
    soma <- soma + x
fimenquanto
media <- soma / total
escreva "Total = ", total
escreva "Soma = ", soma
escreva "Media = ", media
```

**2. Teste de Mesa (Entradas: x=4, x=8, x=0)**

| Instrução | x | total | soma | Saída |
| :--- | :--- | :--- | :--- | :--- |
| `total <- 0` | - | 0 | - | - |
| `soma <- 0` | - | 0 | 0 | - |
| `leia x` | 4 | 0 | 0 | - |
| `se (4 == 0) -> Falso` | 4 | 0 | 0 | - |
| `total <- total + 1` | 4 | 1 | 0 | - |
| `soma <- soma + 4` | 4 | 1 | 4 | - |
| `leia x` | 8 | 1 | 4 | - |
| `se (8 == 0) -> Falso` | 8 | 1 | 4 | - |
| `total <- total + 1` | 8 | 2 | 4 | - |
| `soma <- soma + 8` | 8 | 2 | 12 | - |
| `leia x` | 0 | 2 | 12 | - |
| `se (0 == 0) -> Verdadeiro`| 0 | 2 | 12 | - |
| `media <- 12 / 2` | 0 | 2 | 12 | - |
| `escreva ...` | 0 | 2 | 12 | Total = 2, Soma = 12, Media = 6.0 |

**3. Código em Python**
```python
total = 0 #contador
soma = 0 #acumulador

while True:
    x = int(input())
    if x == 0:
        break
    total += 1
    soma += x

print(f"Total = {total}\nSoma = {soma}\nMedia = {soma/total}")
```

---

## Exercício 7: Laço Finito com Acumulador

**1. Pseudocódigo**
```text
soma <- 0
para i de 0 ate 9 faca
    leia x
    soma <- soma + x
fimpara
escreva soma
```

**2. Teste de Mesa (Amostra com 3 entradas: x=5, x=10, x=2)**

| Instrução | i | x | soma | Saída |
| :--- | :--- | :--- | :--- | :--- |
| `soma <- 0` | - | - | 0 | - |
| `leia x` (i=0) | 0 | 5 | 0 | - |
| `soma <- 0 + 5` | 0 | 5 | 5 | - |
| `leia x` (i=1) | 1 | 10| 5 | - |
| `soma <- 5 + 10`| 1 | 10| 15| - |
| `leia x` (i=2) | 2 | 2 | 15| - |
| `soma <- 15 + 2`| 2 | 2 | 17| - |
| `escreva soma` | - | - | 17| 17 |

**3. Código em Python**
```python
soma = 0

for i in range(0, 10):
    x = int(input())
    soma += x
print(soma)
```

---

## Exercício 8: Somatório Simples com Interrupção

**1. Pseudocódigo**
```text
soma <- 0
enquanto Verdadeiro faca
    leia x
    se x == 0 entao
        interrompa
    fimse
    soma <- soma + x
fimenquanto
escreva "Soma = ", soma
```

**2. Teste de Mesa (Entradas: x=15, x=-5, x=0)**

| Instrução | x | soma | Saída |
| :--- | :--- | :--- | :--- |
| `soma <- 0` | - | 0 | - |
| `leia x` | 15 | 0 | - |
| `se (15 == 0) -> Falso`| 15 | 0 | - |
| `soma <- 0 + 15` | 15 | 15 | - |
| `leia x` | -5 | 15 | - |
| `se (-5 == 0) -> Falso`| -5 | 15 | - |
| `soma <- 15 + (-5)` | -5 | 10 | - |
| `leia x` | 0 | 10 | - |
| `se (0 == 0) -> Verdadeiro`|0 | 10 | - |
| `escreva "Soma = ", soma` | 0 | 10 | Soma = 10 |

**3. Código em Python**
```python
soma = 0

while True:
    x = int(input())
    if x == 0:
        break
    soma += x

print(f"Soma = {soma}")
```

---

## Exercício 9: Série Harmônica

**1. Pseudocódigo**
```text
leia n
soma <- 0.0
para i de 1 ate n faca
    soma <- soma + (1 / i)
fimpara
escreva soma
```

**2. Teste de Mesa (Entrada: n=3)**

| Instrução | n | i | soma | Saída |
| :--- | :--- | :--- | :--- | :--- |
| `leia n` | 3 | - | - | - |
| `soma <- 0.0` | 3 | - | 0.0 | - |
| `soma <- 0.0 + (1/1)` | 3 | 1 | 1.0 | - |
| `soma <- 1.0 + (1/2)` | 3 | 2 | 1.5 | - |
| `soma <- 1.5 + (1/3)` | 3 | 3 | 1.833 | - |
| `escreva soma` | 3 | - | 1.833| 1.833 |

**3. Código em Python**
```python
n = int(input())

soma = 0.0
for i in range(1, n+1):
    soma += 1/i
print(soma)
```

---

## Exercício 10: Processamento em Lote com Condicionais

**1. Pseudocódigo**
```text
total <- 10
aprv <- 0
soma <- 0
para i de 0 ate (total - 1) faca
    leia nota
    soma <- soma + nota
    se nota >= 6 entao
        aprv <- aprv + 1
    fimse
fimpara
escreva "Aprovados (>= 6) = ", aprv
escreva "Media = ", soma/total
```

**2. Teste de Mesa (Amostra simulando total=3: nota=5.0, nota=7.0, nota=6.0)**

| Instrução | nota | i | soma | aprv | Saída |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Inicializações | - | - | 0 | 0 | - |
| `leia nota` | 5.0 | 0 | 0 | 0 | - |
| `soma <- 0 + 5.0` | 5.0 | 0 | 5.0 | 0 | - |
| `se (5.0 >= 6) -> Falso` | 5.0 | 0 | 5.0 | 0 | - |
| `leia nota` | 7.0 | 1 | 5.0 | 0 | - |
| `soma <- 5.0 + 7.0` | 7.0 | 1 | 12.0| 0 | - |
| `se (7.0 >= 6) -> Verdadeiro`| 7.0 | 1 | 12.0| 1 | - |
| `leia nota` | 6.0 | 2 | 12.0| 1 | - |
| `soma <- 12.0 + 6.0` | 6.0 | 2 | 18.0| 1 | - |
| `se (6.0 >= 6) -> Verdadeiro`| 6.0 | 2 | 18.0| 2 | - |
| `escreva ...` | - | - | 18.0| 2 | Aprovados (>= 6) = 2, Media = 6.0 |

**3. Código em Python**
```python
total = 10
aprv = 0
soma = 0

for i in range(0, total):
    nota = float(input())
    soma += nota
    if nota >= 6:
        aprv += 1

print(f"Aprovados (>= 6) = {aprv}\nMedia = {soma/total}")
```

---

## Exercício 11: Análise de Dados Demográficos

**1. Pseudocódigo**
```text
somaIdade <- 0
somaSalario <- 0
qtdM <- 0
total <- 0
totalH <- 0
enquanto Verdadeiro faca
    leia idade
    se idade < 0 entao
        interrompa
    fimse
    leia sexo
    leia salario
    somaIdade <- somaIdade + idade
    se sexo == "M" entao
        somaSalario <- somaSalario + salario
        totalH <- totalH + 1
    senao
        se salario < 600 entao
            qtdM <- qtdM + 1
        fimse
    fimse
    total <- total + 1
fimenquanto
escreva "Media de idade = ", somaIdade/total
escreva "Media Salarios (H) = ", somaSalario/totalH
escreva "Total Mulheres (Salario < 600) = ", qtdM
```

**2. Teste de Mesa (Entradas: 25, "M", 1000, 30, "F", 500, -1)**

| Instrução | idade | sexo | salario | somaIdade | somaSal | totalH | qtdM | total |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| Inicializações | - | - | - | 0 | 0 | 0 | 0 | 0 |
| `leia idade` | 25 | - | - | 0 | 0 | 0 | 0 | 0 |
| `se (25 < 0) -> Falso` | 25 | - | - | 0 | 0 | 0 | 0 | 0 |
| `leia sexo, salario` | 25 | "M" | 1000| 0 | 0 | 0 | 0 | 0 |
| `somaIdade <- 0 + 25` | 25 | "M" | 1000| 25 | 0 | 0 | 0 | 0 |
| `se ("M" == "M") -> Verd`| 25 | "M" | 1000| 25 | 0 | 0 | 0 | 0 |
| `somaSal <- 0 + 1000` | 25 | "M" | 1000| 25 | 1000| 0 | 0 | 0 |
| `totalH <- 0 + 1` | 25 | "M" | 1000| 25 | 1000| 1 | 0 | 0 |
| `total <- 0 + 1` | 25 | "M" | 1000| 25 | 1000| 1 | 0 | 1 |
| `leia idade` | 30 | - | - | 25 | 1000| 1 | 0 | 1 |
| `se (30 < 0) -> Falso` | 30 | - | - | 25 | 1000| 1 | 0 | 1 |
| `leia sexo, salario` | 30 | "F" | 500 | 25 | 1000| 1 | 0 | 1 |
| `somaIdade <- 25 + 30` | 30 | "F" | 500 | 55 | 1000| 1 | 0 | 1 |
| `se ("F" == "M") -> Falso`|30 | "F" | 500 | 55 | 1000| 1 | 0 | 1 |
| `se (500 < 600) -> Verd` | 30 | "F" | 500 | 55 | 1000| 1 | 0 | 1 |
| `qtdM <- 0 + 1` | 30 | "F" | 500 | 55 | 1000| 1 | 1 | 1 |
| `total <- 1 + 1` | 30 | "F" | 500 | 55 | 1000| 1 | 1 | 2 |
| `leia idade` | -1 | - | - | 55 | 1000| 1 | 1 | 2 |
| `se (-1 < 0) -> Verd` | -1 | - | - | 55 | 1000| 1 | 1 | 2 |
| `escreva resultados` | -1 | - | - | 55 | 1000| 1 | 1 | 2 |

**3. Código em Python**
```python
somaIdade = 0
somaSalario = 0
qtdM = 0
total = 0
totalH = 0

while True:
    idade = int(input())
    if idade < 0:
        break
    sexo = input()
    salario = float(input())

    somaIdade += idade
    if sexo == "M":
        somaSalario += salario
        totalH += 1
    else:
        if salario < 600:
            qtdM += 1
    total += 1

print(f"Media de idade = {somaIdade/total}"
      f"\nMedia Salarios (H) = {somaSalario/totalH}"
      f"\nTotal Mulheres (Salario < 600) = {qtdM}")
```