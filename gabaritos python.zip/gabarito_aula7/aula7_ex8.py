def data_magica(dia, mes, ano):
    digito_ano = ano % 100
    if dia*mes == digito_ano:
        return True
    else:
        return False

dia = int(input())
mes = int(input())
ano = int(input())

if data_magica(dia, mes, ano):
    print(f"Data magica: {dia}/{mes}/{ano}")
else:
    print(f"Data Magica:")