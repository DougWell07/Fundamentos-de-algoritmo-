def multiplo(x, y):
    return x%y == 0

x = int(input())
y = int(input())
print(multiplo(x, y))