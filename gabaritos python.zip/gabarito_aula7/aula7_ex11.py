def obter_ordem(A, B, C):
    if A < B and A < C:
        menor = A
        if B < C:
            meio = B
            maior = C
        else:
            meio = C
            maior = B
    elif B < A and B < C:
        menor = B
        if A < C:
            meio = A
            maior = C
        else:
            meio = C
            maior = A
    else:
        menor = C
        if B < A:
            meio = B
            maior = A
        else:
            meio = A
            maior = B
    return menor, meio, maior

def crescente(menor, meio, maior):
    print(f"{menor}, {meio}, {maior}")

def decrescente(menor, meio, maior):
    print(f"{maior}, {meio}, {menor}")

def meioMaior(menor, meio, maior):
    print(f"{menor}, {maior}, {meio}")

I = int(input())
A = int(input())
B = int(input())
C = int(input())

menor, meio, maior = obter_ordem(A, B, C)
if I == 1:
    crescente(menor, meio, maior)
elif I == 2:
    decrescente(menor, meio, maior)
elif I == 3:
    meioMaior(menor, meio, maior)