maximo = lambda x,y: x  if x > y else y  
x = int(input())
y = int(input())
print(maximo(x, y))


multiplo = lambda x,y: x%y==0

x = int(input())
y = int(input())
print(multiplo(x, y))

area_triangulo = lambda base, altura: (base*altura)/2

x = int(input())
y = int(input())
print(area_triangulo(x, y))