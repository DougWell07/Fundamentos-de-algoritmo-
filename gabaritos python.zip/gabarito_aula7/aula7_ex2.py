def media(x, y):
    return (x+y)/2

x = int(input())
y = int(input())
print(media(x, y))