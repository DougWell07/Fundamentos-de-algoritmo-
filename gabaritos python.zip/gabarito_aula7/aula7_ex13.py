def exponencial(n):
    for b in range(n+1):
        for k in range(n+1):
            if b ** k == n:
                return b, k
            

n = int(input())
print(exponencial(n))