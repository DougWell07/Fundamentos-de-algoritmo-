def divisao(dividendo, divisor):
    quociente = 0
    while dividendo - divisor >= 0:
        dividendo -= divisor
        quociente += 1

    resto = dividendo
    return quociente, resto 

x = int(input())
y = int(input())

print(divisao(x, y))