def aptidao(sexo, peso):
    if sexo == "F":
        if peso >= 50:
            return True
        else:
            return False
    else:
        if peso >= 60:
            return True
        else:
            return False

sexo = input()
peso = float(input())

if aptidao(sexo, peso):
    print("Apto")
else:
    print("Não apto")