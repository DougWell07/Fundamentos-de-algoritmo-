def media(x, y):
    print(f"Media = {(x+y)/2}")

x = int(input())
y = int(input())
media(x, y)