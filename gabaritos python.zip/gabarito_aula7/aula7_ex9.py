def data_magica(dia, mes, ano):
    digito_ano = ano % 100
    if dia*mes == digito_ano:
        return True
    else:
        return False

for dia in range(1, 31):
    for mes in range(1, 13):
        for ano in range(1901, 2001):
            if data_magica(dia, mes, ano):
                print(f"Data Magica: {dia}/{mes}/{ano}")