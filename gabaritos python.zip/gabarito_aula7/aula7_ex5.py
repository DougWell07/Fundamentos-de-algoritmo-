def area_triangulo(base, altura):
    return (base * altura)/2

x = int(input())
y = int(input())
print(area_triangulo(x, y))