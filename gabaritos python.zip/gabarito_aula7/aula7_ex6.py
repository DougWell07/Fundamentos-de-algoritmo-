from math import sqrt

def calculo(n1, n2, n3):
    return (sqrt(n1) + sqrt(n2) + sqrt(n3) + ((n1+n2)/2) + ((n2+n3)/2) + ((n1+n3)/2))

n1 = float(input())
n2 = float(input())
n3 = float(input())

print(calculo(n1, n2, n3))