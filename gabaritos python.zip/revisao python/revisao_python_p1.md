# 🧠 Mapa Mental: CCP110 - Fundamentos de Algoritmos

## 📚 1. CONTEÚDO (Lógica e Sintaxe)

### 1.1. Sequencial
* **Entrada e Saída:** `input()`, `print()`
* **Operadores Matemáticos e Atribuição:** `+`, `-`, `*`, `/`, `%` (módulo, resto da divisão), `//` (divisão inteira), `=` (atribuição), `**` (potência)
* **Tipos Primitivos:** `int`, `str` (string), `float`, `bool` (True ou False)
* **Formatação Visual:** `print(f"{valor:.1f}")`, *f-strings*

### 1.2. Condicional
* **Estruturas de Desvio Condicional:** `if`, `else`, `elif`
* **Operadores Relacionais:** `>`, `<`, `>=`, `<=`, `!=`, `==` 
* **Operadores Lógicos (Ordem de prioridade):** `not`, `and`, `or`
* **Tipologia:** Condicional simples (apenas `if`) e completa (`if/else`)

### 1.3. Repetição
* **Iteradores:** `for`, `while` 
* **Controle de Sequência e Fluxo:** `range()`, `break`
* **Laços aninhados:** `for` aninhado

### 1.4. Funções
* **Definição e Retorno:** `def`, `return`, 
* **Parâmetros e Variáveis:** parâmetros `def funcao(x, y)`, param. padrão `def funcao(x=1, y=2)`, `global`
* **Recursos Avançados:** `lambda`

---

## 📐 2. FORMA (Avaliação)

* 📝 **Alternativa**
* ✍️ **Dissertativa**
* 📄 **Pseudo-código: Representação textual estruturada da lógica, independente da sintaxe do Python.**
* 🔲 **Diagrama de Blocos: Representação visual (fluxograma) do fluxo de dados e controle.**
* 📅 **Teste de mesa: Simulação do estado das variáveis na memória durante a execução do algoritmo.**
* 💻 **Código em python: Implementação funcional respeitando a indentação e a sintaxe da linguagem.**

## ⚪ 3. Blocos do Diagrama:
![Blocos do Diagrama](blocos.svg "Blocos do Diagrama")

### 4. Exemplo Pseudocódigo
    algoritmo MenorDeDois
        exiba "Digite um numero: "
        receba n1
        exiba "Digite outro numero: "
        receba n2
        se n1 < n2 entao
            exiba "Menor: ", n1
        se n2 < n1 entao
            exiba "Menor: ", n2
    fim-algoritmo

### 5. Exemplo Diagrama de Blocos
![Exemplo Diagrama de Blocos](aula3_ex1.svg "Diagrama Menor Número")

### 6. Exemplo Teste de Mesa (Entrada: 5, 30)
| Instrução | n1 | n2 | Saída |
| :--- | :--- | :--- | :--- |
| Leia n1 | 5 | - | - |
| Leia n2 | 5 | 30 | - |
| se (5 < 30) -> Verdade | 5 | 30 | Menor: 5 |

### 7. Exemplo Código em Python
```python
n1 = float(input("Digite um numero: "))
n2 = float(input("Digite outro numero: "))

if n1 < n2:
    print(f"Menor: {n1}")
if n2 < n1:
    print(f"Menor: {n2}")
```
