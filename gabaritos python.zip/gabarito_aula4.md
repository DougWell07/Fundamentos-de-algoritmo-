# Gabarito: Estruturas Condicionais e Operadores Lógicos
**Disciplina:** Fundamentos de Algoritmos

Prof. Dr. Murillo Bouzon

---

## Exercício 1: Procedência do Produto

**1. Pseudocódigo**
```text
leia preco
leia codigo
se codigo == 1 entao
    procedencia <- "Sul"
senao se codigo == 2 entao
    procedencia <- "Norte"
senao se codigo == 3 entao
    procedencia <- "Leste"
senao se codigo == 4 entao
    procedencia <- "Oeste"
senao se codigo == 5 ou codigo == 6 entao
    procedencia <- "Nordeste"
senao se codigo >= 7 e codigo <= 9 entao
    procedencia <- "Sudeste"
senao se codigo >= 10 e codigo <= 20 entao
    procedencia <- "Centro-Oeste"
senao se codigo >= 25 e codigo <= 30 entao
    procedencia <- "Nordeste"
senao
    procedencia <- "Importado"
fimse
escreva preco, procedencia
```

**2. Teste de Mesa (Entradas: preco=150.50, codigo=8)**

| Instrução | preco | codigo | procedencia | Saída |
| :--- | :--- | :--- | :--- | :--- |
| `leia preco` | 150.50 | - | - | - |
| `leia codigo` | 150.50 | 8 | - | - |
| `se (8 == 1) -> Falso` | 150.50 | 8 | - | - |
| `senao se (8 == 2) -> Falso` | 150.50 | 8 | - | - |
| `senao se (8 == 3) -> Falso` | 150.50 | 8 | - | - |
| `senao se (8 == 4) -> Falso` | 150.50 | 8 | - | - |
| `senao se (8 == 5 ou 8 == 6) -> Falso` | 150.50 | 8 | - | - |
| `senao se (8 >= 7 e 8 <= 9) -> Verdadeiro`| 150.50 | 8 | - | - |
| `procedencia <- "Sudeste"` | 150.50 | 8 | "Sudeste" | - |
| `escreva preco, procedencia` | 150.50 | 8 | "Sudeste" | 150.50, Sudeste |

**3. Código em Python**
```python
preco = float(input("Digite o preço do produto: "))
codigo = int(input("Digite o código de origem: "))

if codigo == 1:
    procedencia = "Sul"
elif codigo == 2:
    procedencia = "Norte"
elif codigo == 3:
    procedencia = "Leste"
elif codigo == 4:
    procedencia = "Oeste"
elif codigo == 5 or codigo == 6:
    procedencia = "Nordeste"
elif 7 <= codigo <= 9:
    procedencia = "Sudeste"
elif 10 <= codigo <= 20:
    procedencia = "Centro-Oeste"
elif 25 <= codigo <= 30:
    procedencia = "Nordeste"
else:
    procedencia = "Importado"

print(f"Preço: R${preco:.2f} - Procedência: {procedencia}")
```

---

## Exercício 2: Ordem Decrescente

**1. Pseudocódigo**
```text
leia A, B, C
se A > B e A > C entao
    se B > C entao 
        escreva A, B, C
    senao 
        escreva A, C, B
senao se B > A e B > C entao
    se A > C entao 
        escreva B, A, C
    senao 
        escreva B, C, A
senao
    se A > B entao 
        escreva C, A, B
    senao 
        escreva C, B, A
fimse
```

**2. Teste de Mesa (Entradas: A=5, B=9, C=2)**

| Instrução | A | B | C | Saída |
| :--- | :--- | :--- | :--- | :--- |
| `leia A, B, C` | 5 | 9 | 2 | - |
| `se (5 > 9 e 5 > 2) -> Falso` | 5 | 9 | 2 | - |
| `senao se (9 > 5 e 9 > 2) -> Verdadeiro` | 5 | 9 | 2 | - |
| `se (5 > 2) -> Verdadeiro` | 5 | 9 | 2 | - |
| `escreva B, A, C` | 5 | 9 | 2 | 9, 5, 2 |

**3. Código em Python**
```python
a = int(input("Digite o primeiro valor: "))
b = int(input("Digite o segundo valor: "))
c = int(input("Digite o terceiro valor: "))

if a > b and a > c:
    if b > c:
        print(a, b, c)
    else:
        print(a, c, b)
elif b > a and b > c:
    if a > c:
        print(b, a, c)
    else:
        print(b, c, a)
else:
    if a > b:
        print(c, a, b)
    else:
        print(c, b, a)
```

---

## Exercício 3: Cálculo do Peso Ideal

**1. Pseudocódigo**
```text
leia altura, sexo
se sexo == "M" entao
    peso_ideal <- (72.7 * altura) - 58
senao se sexo == "F" entao
    peso_ideal <- (62.1 * altura) - 44.7
senao
    escreva "Sexo inválido"
fimse
escreva peso_ideal
```

**2. Teste de Mesa (Entradas: altura=1.65, sexo="F")**

| Instrução | altura | sexo | peso_ideal | Saída |
| :--- | :--- | :--- | :--- | :--- |
| `leia altura, sexo` | 1.65 | "F" | - | - |
| `se ("F" == "M") -> Falso` | 1.65 | "F" | - | - |
| `senao se ("F" == "F") -> Verdadeiro` | 1.65 | "F" | - | - |
| `peso_ideal <- (62.1 * 1.65) - 44.7` | 1.65 | "F" | 57.765 | - |
| `escreva peso_ideal` | 1.65 | "F" | 57.765 | 57.765 |

**3. Código em Python**
```python
altura = float(input("Digite sua altura em metros: "))
sexo = input("Digite seu sexo (M/F): ").upper()

if sexo == 'M':
    peso_ideal = (72.7 * altura) - 58
    print(f"Seu peso ideal é {peso_ideal:.2f} kg")
elif sexo == 'F':
    peso_ideal = (62.1 * altura) - 44.7
    print(f"Seu peso ideal é {peso_ideal:.2f} kg")
else:
    print("Entrada de sexo inválida. Use M ou F.")
```

---

## Exercício 4: Maioridade e Voto

**1. Pseudocódigo**
```text
leia ano_nascimento
idade <- 2026 - ano_nascimento
escreva "Sua idade é", idade
se idade >= 18 entao
    escreva "Pode votar e pode tirar a CNH."
senao se idade >= 16 entao
    escreva "Pode votar, mas não pode tirar a CNH."
senao
    escreva "Não pode votar e não pode tirar a CNH."
fimse
```

**2. Teste de Mesa (Entrada: ano_nascimento=2010)**

| Instrução | ano_nascimento | idade | Saída |
| :--- | :--- | :--- | :--- |
| `leia ano_nascimento` | 2010 | - | - |
| `idade <- 2026 - 2010` | 2010 | 16 | - |
| `escreva "Sua idade é", idade` | 2010 | 16 | Sua idade é 16 |
| `se (16 >= 18) -> Falso` | 2010 | 16 | - |
| `senao se (16 >= 16) -> Verdadeiro` | 2010 | 16 | - |
| `escreva "Pode votar, mas..."` | 2010 | 16 | Pode votar, mas não pode tirar a CNH. |

**3. Código em Python**
```python
ano_nascimento = int(input("Digite seu ano de nascimento: "))
ano_atual = 2026
idade = ano_atual - ano_nascimento

print(f"Sua idade em {ano_atual} é/será {idade} anos.")

if idade >= 18:
    print("Você já tem idade para votar e conseguir a Carteira de Habilitação.")
elif idade >= 16:
    print("Você tem idade para votar, mas ainda não para a Carteira de Habilitação.")
else:
    print("Você não tem idade para votar nem para a Carteira de Habilitação.")
```

---

## Exercício 5: Classificação de Produtos

**1. Pseudocódigo**
```text
leia codigo
se codigo == 1 entao
    classificacao <- "Alimento não perecível"
senao se codigo >= 2 e codigo <= 4 entao
    classificacao <- "Alimento perecível"
senao se codigo == 5 ou codigo == 6 entao
    classificacao <- "Vestuário"
senao se codigo == 7 entao
    classificacao <- "Higiene pessoal"
senao se codigo >= 8 e codigo <= 15 entao
    classificacao <- "Limpeza e utensílios domésticos"
senao
    classificacao <- "Inválido"
fimse
escreva classificacao
```

**2. Teste de Mesa (Entrada: codigo=6)**

| Instrução | codigo | classificacao | Saída |
| :--- | :--- | :--- | :--- |
| `leia codigo` | 6 | - | - |
| `se (6 == 1) -> Falso` | 6 | - | - |
| `senao se (6 >= 2 e 6 <= 4) -> Falso` | 6 | - | - |
| `senao se (6 == 5 ou 6 == 6) -> Verdadeiro` | 6 | - | - |
| `classificacao <- "Vestuário"` | 6 | "Vestuário" | - |
| `escreva classificacao` | 6 | "Vestuário" | Vestuário |

**3. Código em Python**
```python
codigo = int(input("Digite o código do produto: "))

if codigo == 1:
    classificacao = "Alimento não perecível"
elif 2 <= codigo <= 4:
    classificacao = "Alimento perecível"
elif codigo == 5 or codigo == 6:
    classificacao = "Vestuário"
elif codigo == 7:
    classificacao = "Higiene pessoal"
elif 8 <= codigo <= 15:
    classificacao = "Limpeza e utensílios domésticos"
else:
    classificacao = "Inválido"

print(f"Classificação: {classificacao}")
```