# Revisão: Algoritmos com Lógica Sequencial
**Prof. Dr. Murillo Bouzon** | Centro Universitário FEI

Este documento apresenta a resolução dos exercícios da Aula 02, detalhando a lógica em Pseudocódigo, o Diagrama de Blocos, a validação via Teste de Mesa e a implementação final em Python.

---

## Exercício 01: Peso Ideal
**Problema:** Desenvolver um algoritmo para calcular o peso ideal de um indivíduo a partir de sua altura. A regra matemática aplicada é: (72.7 * altura) - 58.

### 1. Pseudocódigo
    algoritmo PesoIdeal
        exiba "digite sua altura: "
        receba altura
        pesoIdeal = (72.7 * altura) - 58
        exiba "Peso ideal: ", pesoIdeal
    fim-algoritmo

### 2. Diagrama de Blocos
![Diagrama de Blocos do exercício 1](diagrama_pesoIdeal.svg "Diagrama Peso Ideal")

### 3. Teste de Mesa (Entrada: 1.7)
| Passo | Instrução | Var: altura | Var: pesoIdeal | Saída (Tela) |
| :--- | :--- | :--- | :--- | :--- |
| 1 | Início | - | - | - |
| 2 | Escreva "digite sua altura:" | - | - | digite sua altura: |
| 3 | Leia altura (1.7) | 1.7 | - | - |
| 4 | Calc: (72.7 * 1.7) - 58 | 1.7 | 65.59 | - |
| 5 | Escreva "Peso ideal: 65.59" | 1.7 | 65.59 | Peso ideal: 65.59 |

### 4. Python
    # Entrada com conversão para real (float)
    altura = float(input("digite sua altura: "))
    
    # Processamento seguindo a fórmula estabelecida
    peso_ideal = (72.7 * altura) - 58
    
    # Saída formatada
    print(f"Peso ideal: {peso_ideal:.2f}")

---

## Exercício 02: Aluguel de Carro
**Problema:** Calcular o custo total da locação de um veículo considerando uma taxa diária fixa de 60 reais e um custo variável de 15 centavos por quilômetro percorrido.

### 1. Pseudocódigo
    algoritmo PrecoAluguel
        exiba "digite a quantidade de quilometros percorridos: "
        receba km
        exiba "digite a quantidade de dias: "
        receba dias
        total = (dias * 60) + (km * 0.15)
        exiba "Total a pagar: ", total
    fim-algoritmo


### 2. Diagrama de Blocos
![Diagrama de Blocos do exercício 2](diagrama_precoAluguel.svg "Diagrama Preço Aluguel")

### 3. Teste de Mesa (Entrada: 30km, 1 dia)
| Passo | Instrução | Var: km | Var: dias | Var: total | Saída (Tela) |
| :--- | :--- | :--- | :--- | :--- | :--- |
| 1 | Início | - | - | - | - |
| 2 | Leia km (30) | 30 | - | - | digite km: 30 |
| 3 | Leia dias (1) | 30 | 1 | - | digite dias: 1 |
| 4 | Calc: (1 * 60) + (30 * 0.15) | 30 | 1 | 64.50 | - |
| 5 | Escreva "Total a pagar: 64.50" | 30 | 1 | 64.50 | Total a pagar: 64.50 |

### 4. Python
    # Entrada de dados
    km = float(input("digite a quantidade de quilometros percorridos: "))
    dias = int(input("digite a quantidade de dias: "))
    
    # Processamento
    total = (dias * 60.0) + (km * 0.15)
    
    # Saída
    print(f"Total a pagar: {total:.2f}")

---

## Exercício 03: Conversor de Tempo
**Problema:** Criar uma calculadora que recebe grandezas de tempo distintas e unifica tudo em um valor escalar total em segundos.

### 1. Pseudocódigo
    algoritmo TotalSegundos
        exiba "digite a quantidade de dias: "
        receba dias
        exiba "digite a quantidade de horas: "
        receba horas
        exiba "digite a quantidade de minutos: "
        receba minutos
        exiba "digite a quantidade de segundos: "
        receba segundos
        
        total = (dias * 86400) + (horas * 3600) + (minutos * 60) + segundos
        
        exiba "tempo total foi de ", total, " segundos"
    fim-algoritmo

### 2. Diagrama de Blocos
![Diagrama de Blocos do exercício 3](diagrama_totalSegundos.svg "Diagrama Total Segundos")

### 3. Teste de Mesa (Entrada: 1d, 2h, 10m, 5s)
| Passo | Instrução | dias | horas | min | seg | total | Saída (Tela) |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| 1 | Início | - | - | - | - | - | - |
| 2 | Exiba "digite dias..." | - | - | - | - | - | digite a quantidade de dias: |
| 3 | Receba dias (1) | 1 | - | - | - | - | - |
| 4 | Exiba "digite horas..."| 1 | - | - | - | - | digite a quantidade de horas: |
| 5 | Receba horas (2) | 1 | 2 | - | - | - | - |
| 6 | Exiba "digite min..." | 1 | 2 | - | - | - | digite a quantidade de minutos: |
| 7 | Receba minutos (10) | 1 | 2 | 10 | - | - | - |
| 8 | Exiba "digite seg..." | 1 | 2 | 10 | - | - | digite a quantidade de segundos: |
| 9 | Receba segundos (5) | 1 | 2 | 10 | 5 | - | - |
| 10 | Calc (1*86400) + (2*3600)... | 1 | 2 | 10 | 5 | 94205 | - |
| 11 | Exiba total | 1 | 2 | 10 | 5 | 94205 | tempo total foi de 94205 segundos |

### 4. Python
    # Entrada de dados sequencial
    dias = int(input("digite a quantidade de dias: "))
    horas = int(input("digite a quantidade de horas: "))
    minutos = int(input("digite a quantidade de minutos: "))
    segundos = int(input("digite a quantidade de segundos: "))
    
    # Cálculo de conversão e acumulação
    total = (dias * 86400) + (horas * 3600) + (minutos * 60) + segundos
    
    # Saída
    print(f"tempo total foi de {total} segundos")

---

## Exercício 04: Salário e Impostos
**Problema:** Processar uma folha de pagamento calculando o salário bruto com base nas horas trabalhadas e, em seguida, aplicar descontos sequenciais: IR (11%), INSS (8%) e Sindicato (5%).

### 1. Pseudocódigo
    algoritmo SalarioFinal
        exiba "Digite o valor da hora de trabalho: "
        receba v_hora
        exiba "Digite o numero de horas trabalhadas no mes: "
        receba n_horas
        bruto = v_hora * n_horas
        ir = bruto * 0.11
        inss = bruto * 0.08
        sind = bruto * 0.05
        liquido = bruto - ir - inss - sind
        exiba "Salario Bruto: R$ ", bruto
        exiba "IR (11%): R$ ", ir
        exiba "INSS (8%): R$ ", inss
        exiba "Sindicato (5%): R$ ", sind
        exiba "Salario liquido: R$ ", liquido
    fim-algoritmo

### 2. Diagrama de Blocos
![Diagrama de Blocos do exercício 4](diagrama_salarioFinal.svg "Diagrama Salario Final")

### 3. Teste de Mesa (Entrada: R$ 50, 80h)
| Passo | Instrução | v_hora | n_horas | Bruto | IR | INSS | Sind | Líquido | Saída (Tela) |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| 1 | Início | - | - | - | - | - | - | - | - |
| 2 | Exiba "Digite valor da hora..." | - | - | - | - | - | - | - | Digite valor da hora... |
| 3 | Receba v_hora (50) | 50 | - | - | - | - | - | - | - |
| 4 | Exiba "Digite numero de horas..."| 50 | - | - | - | - | - | - | Digite numero de horas... |
| 5 | Receba n_horas (80) | 50 | 80 | - | - | - | - | - | - |
| 6 | Calc bruto (50 * 80) | 50 | 80 | 4000 | - | - | - | - | - |
| 7 | Calc ir (4000 * 0.11) | 50 | 80 | 4000 | 440 | - | - | - | - |
| 8 | Calc inss (4000 * 0.08) | 50 | 80 | 4000 | 440 | 320 | - | - | - |
| 9 | Calc sind (4000 * 0.05) | 50 | 80 | 4000 | 440 | 320 | 200 | - | - |
| 10 | Calc liquido | 50 | 80 | 4000 | 440 | 320 | 200 | 3040 | - |
| 11 | Exiba bruto | 50 | 80 | 4000 | 440 | 320 | 200 | 3040 | Salario Bruto: 4000.00 |
| 12 | Exiba ir | 50 | 80 | 4000 | 440 | 320 | 200 | 3040 | IR (11%): 440.00 |
| 13 | Exiba inss | 50 | 80 | 4000 | 440 | 320 | 200 | 3040 | INSS (8%): 320.00 |
| 14 | Exiba sind | 50 | 80 | 4000 | 440 | 320 | 200 | 3040 | Sindicato (5%): 200.00 |
| 15 | Exiba liquido | 50 | 80 | 4000 | 440 | 320 | 200 | 3040 | Salario liquido: 3040.00 |

### 4. Python
    # Entrada de dados
    v_hora = float(input("Digite o valor da hora de trabalho: "))
    n_horas = float(input("Digite o numero de horas trabalhadas no mes: "))
    
    # Cálculos processados em sequencia
    bruto = v_hora * n_horas
    ir = bruto * 0.11
    inss = bruto * 0.08
    sind = bruto * 0.05
    liquido = bruto - ir - inss - sind
    
    # Exibição dos resultados linha a linha
    print(f"Salario Bruto: R$ {bruto:.2f}")
    print(f"IR (11%): R$ {ir:.2f}")
    print(f"INSS (8%): R$ {inss:.2f}")
    print(f"Sindicato (5%): R$ {sind:.2f}")
    print(f"Salario liquido: R$ {liquido:.2f}")