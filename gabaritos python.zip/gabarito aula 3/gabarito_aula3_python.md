# Gabarito Completo: Estruturas Condicionais e Operadores Relacionais
**Prof. Dr. Murillo Bouzon** | Departamento de Ciência da Computação

Este documento apresenta a resolução analítica de todos os exercícios da Aula 03. Para cada desafio, modelamos a solução em Pseudocódigo, validamos a lógica através de um Teste de Mesa e materializamos a solução em Python.

---

## Exercício 01: O Menor de Dois Números
**Problema:** Faça um programa que peça dois números e imprima o menor deles, usando apenas Estruturas de Decisão Simples.

### 1. Pseudocódigo
    algoritmo MenorDeDois
        exiba "Digite um numero: "
        receba n1
        exiba "Digite outro numero: "
        receba n2
        se n1 < n2 entao
            exiba "Menor: ", n1
        se n2 < n1 entao
            exiba "Menor: ", n2
    fim-algoritmo

### 2. Diagrama de Blocos
![Diagrama de Blocos do exercício 1](aula3_ex1.svg "Diagrama Menor Número")

### 3. Teste de Mesa (Entrada: 5, 30)
| Instrução | n1 | n2 | Saída |
| :--- | :--- | :--- | :--- |
| Leia n1 | 5 | - | - |
| Leia n2 | 5 | 30 | - |
| se (5 < 30) -> Verdade | 5 | 30 | Menor: 5 |

### 4. Python
```python
n1 = float(input("Digite um numero: "))
n2 = float(input("Digite outro numero: "))

if n1 < n2:
    print(f"Menor: {n1}")
if n2 < n1:
    print(f"Menor: {n2}")
```

---

## Exercício 02: Positivo ou Negativo
**Problema:** Peça um valor numérico. Escreva na tela se o valor é positivo ou negativo, utilizando apenas Estruturas de Decisão Completas.

### 1. Pseudocódigo
    algoritmo ValidaSinal
        exiba "Digite um numero: "
        receba num
        se num > 0 entao
            exiba "positivo"
        senao
            exiba "negativo"
    fim-algoritmo


### 2. Diagrama de Blocos
![Diagrama de Blocos do exercício 2](aula3_ex2.svg "Diagrama Positivo e Negativo")


### 3. Teste de Mesa (Entrada: -2)
| Instrução | num | Saída |
| :--- | :--- | :--- |
| Leia num | -2 | - |
| se (-2 > 0) -> Falso | -2 | - |
| senao | -2 | negativo |

### 4. Python
```python
num = float(input("Digite um numero: "))

if num > 0:
    print("positivo")
else:
    print("negativo")
```

---

## Exercício 03: Dia da Semana
**Problema:** Leia um número e exiba o dia correspondente da semana usando apenas Estruturas de Decisão Simples.

### 1. Pseudocódigo
    algoritmo DiaSemana
        receba dia
        se dia == 1 entao exiba "1 - Domingo"
        se dia == 2 entao exiba "2 - Segunda"
        se dia == 3 entao exiba "3 - Terça"
        se dia == 4 entao exiba "4 - Quarta"
        se dia == 5 entao exiba "5 - Quinta"
        se dia == 6 entao exiba "6 - Sexta"
        se dia == 7 entao exiba "7 - Sábado"
        ...
    fim-algoritmo

### 2. Teste de Mesa (Entrada: 3)
| Instrução | dia | Saída |
| :--- | :--- | :--- |
| Leia dia | 3 | - |
| se (dia == 3) -> Verdade | 3 | 3 - Terça |

### 3. Python
```python
dia = int(input("Digite o numero do dia (1 a 7): "))

if dia == 1: 
    print("1 - Domingo")
if dia == 2: 
    print("2 - Segunda")
if dia == 3: 
    print("3 - Terça")
if dia == 4: 
    print("4 - Quarta")
if dia == 5: 
    print("5 - Quinta")
if dia == 6: 
    print("6 - Sexta")
if dia == 7: 
    print("7 - Sábado")
```

---

## Exercício 04: Aumento Salarial
**Problema:** Calcule o aumento de salário: superiores a R$ 1250,00 recebem 10%; inferiores ou iguais recebem 15%. Imprima o novo salário usando Estruturas de Decisão Completas.

### 1. Pseudocódigo
    algoritmo AumentoSalario
        receba salario
        se salario > 1250.00 entao
            novo = salario * 1.10
        senao
            novo = salario * 1.15
        exiba novo
    fim-algoritmo

    
### 2. Diagrama de Blocos
![Diagrama de Blocos do exercício 4](aula3_ex4.svg "Diagrama Aumento Salarial")


### 3. Teste de Mesa (Entrada: 1000)
| Instrução | salario | novo_salario | Saída |
| :--- | :--- | :--- | :--- |
| Leia salario | 1000 | - | - |
| se (1000 > 1250) -> Falso | 1000 | - | - |
| senao -> (1000 * 1.15) | 1000 | 1150 | R$ 1150.00 |

### 4. Python
```python
salario = float(input("Qual o salario atual? "))

if salario > 1250.00:
    novo_salario = salario * 1.10
else:
    novo_salario = salario * 1.15

print(f"Novo salário: R$ {novo_salario:.2f}")
```

---

## Exercício 05: Verificação de CNH
**Problema:** Leia ano atual e de nascimento, calcule a idade. Se maior ou igual a 18, mostre que pode tirar CNH, usando Decisão Simples.

### 1. Pseudocódigo
    algoritmo VerificaCNH
        receba ano_atual, ano_nasc
        idade = ano_atual - ano_nasc
        se idade >= 18 entao
            exiba "Pode tirar CNH"
    fim-algoritmo

### 2. Teste de Mesa (Entrada: 2026, 2005)
| Instrução | atual | nasc | idade | Saída |
| :--- | :--- | :--- | :--- | :--- |
| Leia anos | 2026 | 2005 | - | - |
| Calc idade | 2026 | 2005 | 21 | - |
| se (21 >= 18) -> Verdade| 2026 | 2005 | 21 | Pode tirar CNH |

### 3. Python
```python
ano_atual = int(input("Ano atual: "))
ano_nasc = int(input("Ano de nascimento: "))
idade = ano_atual - ano_nasc

if idade >= 18:
    print("Você pode tirar a sua CNH!")
```

---

## Exercício 06: Classificação de Veículo
**Problema:** Diga se um carro é novo (< 3 anos) ou velho (>= 3 anos) usando Decisão Completa.

### 1. Pseudocódigo
    algoritmo ClassificaCarro
        receba idade_carro
        se idade_carro < 3 entao
            exiba "novo"
        senao
            exiba "velho"
    fim-algoritmo

### 2. Teste de Mesa (Entrada: 4)
| Instrução | idade_carro | Saída |
| :--- | :--- | :--- |
| Leia idade | 4 | - |
| se (4 < 3) -> Falso | 4 | - |
| senao | 4 | velho |

### 3. Python
```python
idade_carro = float(input("Idade do carro (em anos): "))

if idade_carro < 3:
    print("O carro é considerado novo.")
else:
    print("O carro é considerado velho.")
```

---

## Exercício 07: Preço da Passagem
**Problema:** Calcule o preço da passagem: R$ 0,50/km para até 200 km; R$ 0,45/km para viagens mais longas. Decisão Completa.

### 1. Pseudocódigo
    algoritmo PrecoPassagem
        receba distancia
        se distancia <= 200 entao
            preco = distancia * 0.50
        senao
            preco = distancia * 0.45
        exiba preco
    fim-algoritmo

### 2. Teste de Mesa (Entrada: 250)
| Instrução | distancia | preco | Saída |
| :--- | :--- | :--- | :--- |
| Leia distancia | 250 | - | - |
| se (250 <= 200) -> Falso | 250 | - | - |
| senao -> (250 * 0.45) | 250 | 112.50 | R$ 112.50 |

### 3. Python
```python
distancia = float(input("Distância em km: "))

if distancia <= 200:
    preco = distancia * 0.50
else:
    preco = distancia * 0.45

print(f"Preço total da passagem: R$ {preco:.2f}")
```

---

## Exercício 08: Tanques Cilíndricos
**Problema:** Calcular latas e custo para pintar tanques. Lata=5L. 1L=3m². Preços variam por quantidade.

### 1. Pseudocódigo
    algoritmo PinturaTanque
        receba altura, raio
        area_base = 3.1415 * (raio * raio)
        perimetro = 2 * 3.1415 * raio
        area_lateral = altura * perimetro
        area_total = area_base + area_lateral
        
        litros = area_total / 3
        latas = arredonda_para_cima(litros / 5)
        
        se latas == 1 entao 
            preco = 50.00
        senao 
            se latas == 2 entao 
                preco = 48.00
            senao 
                se latas == 3 entao 
                    preco = 46.00
                senao 
                    preco = 45.00
        
        exiba custo = latas * preco
    fim-algoritmo


### 2. Diagrama de Blocos
![Diagrama de Blocos do exercício 8](aula3_ex8.svg "Diagrama Pintura Cilindro")


### 3. Teste de Mesa (Entrada: Altura 1, Raio 1)
| Instrução | altura | raio | area_total | litros | latas | preco | custo |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| Leia dados | 1 | 1 | - | - | - | - | - |
| Calc area_total | 1 | 1 | 9.42 | - | - | - | - |
| Calc litros (9.42 / 3) | 1 | 1 | 9.42 | 3.14 | - | - | - |
| Calc latas ceil(3.14/5)| 1 | 1 | 9.42 | 3.14 | 1 | - | - |
| se (1 == 1) -> V | 1 | 1 | 9.42 | 3.14 | 1 | 50.00 | 50.00 |

### 4. Python
```python
import math

altura = float(input("Altura do tanque: "))
raio = float(input("Raio do tanque: "))

# Cálculos Geométricos
area_base = math.pi * (raio ** 2)
perimetro = 2 * math.pi * raio
area_lateral = altura * perimetro
area_total = area_base + area_lateral

# Rendimento
litros_necessarios = area_total / 3.0
latas = math.ceil(litros_necessarios / 5.0)

# Estrutura de Precificação Aninhada
if latas == 1:
    preco_un = 50.00
else:
    if latas == 2:
        preco_un = 48.00
    else:
        if latas == 3:
            preco_un = 46.00
        else:
            preco_un = 45.00

custo_total = latas * preco_un

print(f"\nÁrea a ser pintada: {area_total:.2f}")
print(f"Qtde de litros: {litros_necessarios:.2f}")
print(f"Latas necessárias: {latas}")
print(f"Preço unitário: R$ {preco_un:.2f}")
print(f"Custo total: R$ {custo_total:.2f}")
