N = int(input())
for i in range(N):
    for j in range(N):
        if i % 2 == 0:
            if j % 2 == 0:
                print('$', end=' ')
            else:
                print('&', end=' ')
        else:
            if j % 2 == 0:
                print('%', end=' ')
            else:
                print('#', end=' ')
    print()