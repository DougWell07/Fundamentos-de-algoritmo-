totalPrimos = 0

N = int(input())
for i in range(N):
    X = int(input())
    if X > 1:
        primo = 1
        for j in range(2, X):
            if X % j == 0:
                primo = 0

        totalPrimos += primo 

print(totalPrimos)   