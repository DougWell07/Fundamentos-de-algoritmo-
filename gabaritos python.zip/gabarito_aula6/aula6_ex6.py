N = int(input())
digitos = 0
while(N > 0):
    digitos += 1
    N //= 10
print(digitos)