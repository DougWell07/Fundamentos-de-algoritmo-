N = int(input())
for i in range(N):
    for j in range(N):
        if (i+j) % 2 == 0:
            print('o', end=' ')
        else:
            print('*', end=' ')
    print()