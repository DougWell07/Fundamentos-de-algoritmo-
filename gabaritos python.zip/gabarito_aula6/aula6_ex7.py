ant = 0
prox = 1
N = int(input())

fib = 0

if N > 0:
    while prox <= N:
        aux = prox
        prox = prox + ant
        ant = aux

        if N == prox:
            fib = 1
            break
else:
    fib = 1

if fib:
    print("Verdadeiro")
else:
    print("Falso")

